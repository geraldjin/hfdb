define(['d'], function (d) {
    return {
        name: 'e',
        d: d
    };
});
