define({
    load: function (name, req, load, config) {
        load('x');
    }
});
