
define(function (require) {
    return {
        id1: require('dynamic!medium'),
        id2: require('dynamic!medium'),
        name: 'mattress'
    };
});
