define('b', [], function () {
    return {
        name: 'b'
    };
});
