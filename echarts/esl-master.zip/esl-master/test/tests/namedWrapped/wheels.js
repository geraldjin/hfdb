define('wheels', function (require, exports, module) {
    exports.name = 'wheels';
});
