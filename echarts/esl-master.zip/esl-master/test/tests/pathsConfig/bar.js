define(function () {
    return {
        name: 'bar'
    };
});
