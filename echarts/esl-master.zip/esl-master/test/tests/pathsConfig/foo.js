define(function () {
    return {
        name: 'foo'
    };
});
