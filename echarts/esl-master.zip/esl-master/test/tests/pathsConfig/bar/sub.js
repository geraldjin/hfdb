define(function () {
    return {
        name: 'barSub'
    };
});
