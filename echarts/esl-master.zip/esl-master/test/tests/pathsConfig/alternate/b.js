define(function () {
    return {
        name: 'fooB'
    };
});
