define(function () {
    return {
        name: 'fooC'
    };
});
