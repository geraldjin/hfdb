define(function(){
    return 'four';
});
