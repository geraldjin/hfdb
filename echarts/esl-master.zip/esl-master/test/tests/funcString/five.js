define(function(){
    return function () {
        return 'five';
    }
});
