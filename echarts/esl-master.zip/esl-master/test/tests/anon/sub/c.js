define(function () {
    return {
        name: 'c'
    };
});
