define('a', {
    name: 'a'
});
