define('sub/c', function () {
    return {
        name: 'c'
    };
});
