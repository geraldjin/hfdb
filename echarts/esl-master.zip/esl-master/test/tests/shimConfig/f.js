var FCAP = {
    name: 'FCAP',
    globalA: A
};
