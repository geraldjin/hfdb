define(function (require) {
    return {
        lib: require('map-and-pkg-lib')
    };
});
