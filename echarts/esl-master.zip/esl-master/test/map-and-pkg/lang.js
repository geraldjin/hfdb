define({
    name: 'lang'
});
