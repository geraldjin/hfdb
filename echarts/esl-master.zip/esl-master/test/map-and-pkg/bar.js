define(function (require) {
    return {
        lang: require('map-and-pkg/lang')
    };
});
