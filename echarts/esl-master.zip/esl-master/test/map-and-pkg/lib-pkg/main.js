define(function (require) {
    return {
        name: 'map-and-pkg-lib/main'
    };
});
