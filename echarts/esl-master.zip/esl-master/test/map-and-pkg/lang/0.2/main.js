define({
    name: 'lang-0.2'
});
