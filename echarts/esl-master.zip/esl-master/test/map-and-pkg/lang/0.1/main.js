define({
    name: 'lang-0.1'
});
