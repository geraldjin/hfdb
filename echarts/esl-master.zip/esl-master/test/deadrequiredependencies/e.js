define(
    function (require) {
        require('./f').name;
        return {name: 'e'};
    }
);
