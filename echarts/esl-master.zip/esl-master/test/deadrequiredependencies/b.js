define(
    function (require) {
        require('./c').name;
        return {name: 'b'};
    }
);
