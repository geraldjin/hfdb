define(
    function (require) {
        require('./e').name;
        return {name: 'd'};
    }
);
