define(
    function (require) {
        return {name: 'g'};
    }
);
