define(
    function (require) {
        require('./d').name;
        return {name: 'c'};
    }
);
