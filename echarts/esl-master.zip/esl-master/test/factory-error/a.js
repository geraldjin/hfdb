define( function ( require ) {
    require('./b');
    require('./c');
    return {name: 'factory-error/a'}
});
