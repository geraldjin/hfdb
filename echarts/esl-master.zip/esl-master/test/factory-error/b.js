define( function ( require ) {
    alert( noExistsVariable );
    return {name: 'factory-error/b'}
});
