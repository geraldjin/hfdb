define( function ( require ) {
    return {name: 'factory-error/c'}
});
