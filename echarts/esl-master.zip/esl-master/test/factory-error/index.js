define( function ( require ) {
    require('./a');
    return {name: 'factory-error/index'}
});
