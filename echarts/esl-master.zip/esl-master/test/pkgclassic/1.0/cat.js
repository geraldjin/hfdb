define( function ( require, exports ) {
    exports.name = 'pkgclassic/cat'
} );