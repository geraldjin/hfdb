define({
    name: 'meaninglessDefine/index'
});