define( 
    function ( require, exports, module ) {
    	require( 'css!./style-local.css' );
        module.exports = {
            name: 'cssplugin/index'
        };
    }
);