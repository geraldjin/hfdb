define( {
    name: 'abspath/index'
} );
