define( {
    name: 'relapath/index'
} );
