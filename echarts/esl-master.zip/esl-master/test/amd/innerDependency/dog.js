define( 
    'amd/innerDependency/dog',
    function () {
        return {
            name: 'amd/innerDependency/dog'
        };
    }
);