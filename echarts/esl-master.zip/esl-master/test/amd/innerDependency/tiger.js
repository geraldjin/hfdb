define( 
    'amd/innerDependency/tiger',
    function () {
        return {
            name: 'amd/innerDependency/tiger'
        };
    }
);