define( 
    'amd/innerDependency/lion',
    function () {
        return {
            name: 'amd/innerDependency/lion'
        };
    }
);