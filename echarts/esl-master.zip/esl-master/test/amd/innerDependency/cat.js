define( 
    'amd/innerDependency/cat',
    function () {
        return {
            name: 'amd/innerDependency/cat'
        };
    }
);