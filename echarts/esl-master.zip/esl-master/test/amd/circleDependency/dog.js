define( 
    'amd/circleDependency/dog',
    function () {
        return {
            name: 'amd/circleDependency/dog'
        };
    }
);