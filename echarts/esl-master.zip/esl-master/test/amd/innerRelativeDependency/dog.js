define( 
    'amd/innerRelativeDependency/dog',
    function () {
        return {
            name: 'amd/innerRelativeDependency/dog'
        };
    }
);