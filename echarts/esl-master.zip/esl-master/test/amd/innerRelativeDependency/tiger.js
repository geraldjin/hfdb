define( 
    'amd/innerRelativeDependency/tiger',
    function () {
        return {
            name: 'amd/innerRelativeDependency/tiger'
        };
    }
);