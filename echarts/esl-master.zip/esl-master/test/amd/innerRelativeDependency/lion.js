define( 
    'amd/innerRelativeDependency/lion',
    function () {
        return {
            name: 'amd/innerRelativeDependency/lion'
        };
    }
);