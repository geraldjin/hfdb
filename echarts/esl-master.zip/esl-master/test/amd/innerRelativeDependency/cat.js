define( 
    'amd/innerRelativeDependency/cat',
    function () {
        return {
            name: 'amd/innerRelativeDependency/cat'
        };
    }
);