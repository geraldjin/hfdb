define(
    {
        name: 'amd/btModuleId/has.dot'
    }
);