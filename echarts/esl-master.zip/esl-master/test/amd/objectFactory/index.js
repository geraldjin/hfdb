define( 'amd/objectFactory/index', {
    name: 'amd/objectFactory/index'
} );