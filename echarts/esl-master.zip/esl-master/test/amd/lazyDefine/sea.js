define( function( require ) {
    window.__eslLazyDefine = 'sea';
    return {
        name: 'amd/lazyDefine/sea'
    };
});