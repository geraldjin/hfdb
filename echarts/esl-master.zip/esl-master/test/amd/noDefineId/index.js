define( function () {
    return {
        name: 'amd/noDefineId/index'
    };
} );