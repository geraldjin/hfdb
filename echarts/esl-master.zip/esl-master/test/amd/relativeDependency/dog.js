define( 
    function () {
        return {
            name: 'amd/relativeDependency/dog'
        };
    }
);