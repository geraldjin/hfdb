define( 
    function ( dog ) {
        return {
            name: 'amd/relativeDependency/inner/cat'
        };
    }
);