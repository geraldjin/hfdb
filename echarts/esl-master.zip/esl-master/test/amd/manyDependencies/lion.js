define( 
    function () {
        return {
            name: 'amd/manyDependencies/lion'
        };
    }
);