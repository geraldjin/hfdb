define( 
    function () {
        return {
            name: 'amd/manyDependencies/dog'
        };
    }
);