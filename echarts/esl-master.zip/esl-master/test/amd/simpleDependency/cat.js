define( 
    'amd/simpleDependency/cat',
    function () {
        return {
            name: 'amd/simpleDependency/cat'
        };
    }
);