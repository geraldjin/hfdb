define(
    function ( require ) {
        function test() {
            require( './f' ).name;
        }
        return {name: 'e'};
    }
);