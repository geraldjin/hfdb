define(
    ['./a'],
    function (a) {
        a.name;
        return {name: 'g'};
    }
);