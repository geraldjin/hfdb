define(
    ['./e'],
    function (e) {
        e.name;
        return {name: 'd'};
    }
);