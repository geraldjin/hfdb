define(
    ['./d'],
    function (d) {
        d.name;
        return {name: 'c'};
    }
);