define(
    ['./c', './g'],
    function (c,g) {
        c.name;g.name;
        return {name: 'f'};
    }
);