define(
    ['./c'],
    function (c) {
        c.name;
        return {name: 'b'};
    }
);