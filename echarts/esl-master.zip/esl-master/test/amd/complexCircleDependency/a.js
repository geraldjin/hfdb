define(
    ['./b'],
    function (b) {
        b.name;
        return {name: 'a'};
    }
);