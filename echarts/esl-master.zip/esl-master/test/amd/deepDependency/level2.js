define( 
    'amd/deepDependency/level2',
    function () {
        return {
            name: 'amd/deepDependency/level2'
        };
    }
);