define( 
    'amd/deepDependency/level21',
    function () {
        return {
            name: 'amd/deepDependency/level21'
        };
    }
);