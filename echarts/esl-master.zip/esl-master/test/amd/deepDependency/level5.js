define( 
    'amd/deepDependency/level5',
    function () {
        return {
            name: 'amd/deepDependency/level5'
        };
    }
);