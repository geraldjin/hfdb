define( 
    'amd/deepDependency/level31',
    function () {
        return {
            name: 'amd/deepDependency/level31'
        };
    }
);