define( function ( require ) {
    return {
        name: 'amd/deepDependency2/level3'
    };
})
