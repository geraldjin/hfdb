define( function ( require ) {
    return {
        name: 'amd/deepDependency3/c'
    };
} );
