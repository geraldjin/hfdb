define( 'amd/simple/index', function () {
    return {
        name: 'amd/simple/index'
    };
} );