define({
    name: 'complexProcess/mixed/empty'
});
