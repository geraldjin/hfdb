define({
    name: 'complexProcess/pure/empty'
});
