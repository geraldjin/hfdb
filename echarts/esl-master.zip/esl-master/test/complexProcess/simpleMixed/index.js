define(
    function (require) {
        return {
            name: 'complexProcess/simpleMixed/index',
            res: require('complexProcess/simpleMixed/text!x')
        };
    }
);
