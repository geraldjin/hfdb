define({
    name: 'complexProcess/simpleMixed/empty'
});
