define( 
    function ( require, exports, module ) {
        exports.name = 'simple2/cat';
    }
);