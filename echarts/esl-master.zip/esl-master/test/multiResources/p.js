define({
    load: function ( name, req, load ) {
        load( name );
    }
});