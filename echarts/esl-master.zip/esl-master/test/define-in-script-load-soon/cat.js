define({
    name: 'define-in-script-load-soon/cat'
})
