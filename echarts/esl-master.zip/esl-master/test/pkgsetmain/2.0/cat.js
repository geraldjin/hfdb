define( function ( require, exports ) {
    exports.name = 'pkgsetmain/cat'
} );