var shimPureD = {
    name: 'shim pure d'
};
