(function (global) {

global.shimPureC = {
    name: 'shim pure c',
    ename: shimPureEOther.name,
    dname: global.shimPureD.name
};

})(this);
