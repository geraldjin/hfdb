var shimPureEOther = {
    name: 'shim pure e'
};
