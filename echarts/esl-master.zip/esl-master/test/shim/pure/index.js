var shimPureIndex = {
    exports: {
        name: 'shim pure index',
        a: shimPureA,
        b: shimPureBOther,
        bname: shimPureBOther.name
    }
};
