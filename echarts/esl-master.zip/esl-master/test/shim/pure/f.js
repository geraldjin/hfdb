var shimPureFName = 'shim pure f';
