var shimPureA = {
    name: 'shim pure a'
};



