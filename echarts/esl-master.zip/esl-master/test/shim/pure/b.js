
var shimPureBOther = {
    name: 'shim pure b'
};

