define({
    name: 'shim mixed amdBase'    
});
