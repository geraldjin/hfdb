
var shimMixedSFOther = {
    name: 'shim mixed sf',
    c: shimMixedSC
};

