
var shimMixedSE = {
    name: 'shim mixed se',
    d: shimMixedSDOther,
    c: shimMixedSC
};

