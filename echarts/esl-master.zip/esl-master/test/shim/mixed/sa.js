(function (global) {
    shimMixedSFOther.name;
    shimMixedSE.name;

    global.shimMixedSA = {
        name: 'shim mixed sa'
    };
})(this);
