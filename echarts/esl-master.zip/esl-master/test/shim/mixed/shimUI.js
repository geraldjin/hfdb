(function (global) {
    if ($$$$$$.name !== 'shim mixed lib') {
        return;
    }

    global.shimMixedUI = {
        name: 'shim mixed ui'
    };
})(this);
