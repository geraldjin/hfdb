
var shimMixedSDOther = {
    name: 'shim mixed sd'
};

