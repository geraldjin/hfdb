define(function (require) {
    return {
        name: 'shim mixed amdC'
    };
});

