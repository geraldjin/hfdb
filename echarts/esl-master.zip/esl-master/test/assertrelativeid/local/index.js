define( function ( require ) {
    var a = require( './a' );
    return {a:a};
} )