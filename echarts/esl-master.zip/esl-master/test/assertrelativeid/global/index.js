define( function () {
    var a = require( './a' );
    return {a:a};
} )