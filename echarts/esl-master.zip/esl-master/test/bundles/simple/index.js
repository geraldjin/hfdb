define({ name: 'bundles/simple/index' })

define( 'bundles/simple/plugin!resource', function () {
    return 'bundles/simple/plugin!resource';
});
    

define( 'bundles/simple/cat', function () {
    return { name: 'bundles/simple/cat' }
} )
