define( function () {
    return { name: 'bundles/simple/sbcat' }
} )
