define(
    function () {
        return {
            name: 'bundlesPackage/main'
        };
    }
);
