define({
    name: 'bundles/complex/lib-err'
})
