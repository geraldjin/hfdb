define( function ( require ) {

    return {
        name: 'deepResources/ab',
        check: function () {
            return true;
        }
    };
});
