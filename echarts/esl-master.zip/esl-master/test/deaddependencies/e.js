define(
    ['./f'],
    function (f) {
        f.name;
        return {name: 'e'};
    }
);