test包含了自己写的一些测试用例，以及官方的测试用例。


自己的测试用例运行方法：

	http://localhost/test/test.html?autostart

官方测试用例运行方法：

	http://localhost/test/tests/doh/runner.html?config=esl/config.js&impl=esl/esl.js


官方测试用例见：https://github.com/amdjs/amdjs-tests